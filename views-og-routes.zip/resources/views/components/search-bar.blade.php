     <!-- SEARCH-BAR -->
     <div class="col-lg-9">

        <h1 class="mb-4"> THRIFT&TRADE PRODUCTS IN YOUR LOCAL AREAS!
            <div class="mt-3">
                <form class="d-flex">
                    <input class="form-control me-2" type="search" placeholder="Search Listings..."
                        aria-label="Search">
                    <button class="btn btn-outline-primary" type="submit">Search</button>
                </form>
    </div>
    <!-- END SEARCH BAR -->