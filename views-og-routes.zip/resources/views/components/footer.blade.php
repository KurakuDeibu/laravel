  <!-- FOOTER -->
  <footer class="bg-light mt-5 py-4">
    <div class="container text-center">
      <p>© 2024 ThriftyTrade. All rights reserved.</p>
      <p>
        <a href="/terms" class="text-decoration-none me-2">Terms of Service</a>
        <a href="/privacy" class="text-decoration-none me-2">Privacy Policy</a>
        <a href="/contact" class="text-decoration-none">Contact Us</a>
      </p>
    </div>
  </footer>
  <!-- END OF FOOTER -->